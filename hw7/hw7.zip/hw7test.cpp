#include <stdio.h>
#include <stdlib.h>







int main(void)
{
        srand(14530529);
        for (int i=1;i<=3;i++) {
                printf("Unsorted data %d ***\n",i);
                randperm(n); randscore(n); out(n);
                printf("Cycle-sort by student numbers ...\n");
                cyclesort(n);
                out(n);
                printf("Gnome-sort by midterm scores  ...\n");
                gnomesort(n);
                out(n);
                printf("\n");
        }
}


