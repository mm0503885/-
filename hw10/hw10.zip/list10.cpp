#include <stdio.h>
#include <stdlib.h>

typedef struct node { int datum; struct node* succ; } node;	 

void print(node* p)
{
   	if (p==NULL) printf("\n"); 
	else { printf("%d ",p->datum); print(p->succ); }
}

bool find(node* p,int d) 
{
   	if (p==NULL) return false;
	else if (p->datum==d) return true;
	else return find(p->succ,d); 
}

//void insert(node** p,int d)
//{
//  		node* q=(node*)malloc(sizeof(node));
//   	q->datum=d;
//		q->succ=*p;
//		*p=q;
//}

node* insert(node* p,int d)
{
  	node* q=(node*)malloc(sizeof(node));
   	q->datum=d;
	q->succ=p;
	return q;
}

//void erase(node** p,int d)
//{
//   	node *q=*p,*r;
//   	while (q!=NULL) 
//     	if (q->datum==d) break; 
//     	else { r=q; q=q->succ; }
//	if (q!=NULL) {
//     	if (q==*p) *p=(*p)->succ; 
//     	else r->succ=q->succ; 
//     	free(q); 
//   	}
//}

node* erase(node* p,int d)
{
   	if (p!=NULL) 
		if (p->datum==d) { node* q=p; p=p->succ; free(q); }
		else p->succ=erase(p->succ,d);
	return p;
}

void eraseAll(node* p)
{
	if (p!=NULL) { eraseAll(p->succ); free(p); }
}

int main(void)			
{
   	node* head=NULL;
   	int ch;  
	printf("Command: ");
	while ((ch=getchar())!=EOF) {
   		switch(ch) {
      		int d;
		case 'd':	
			scanf("%d",&d); head=erase(head,d); break;
		case 'e':	
			scanf("%d",&d); eraseLast(&head,d); break;
		case 'E':	
			scanf("%d",&d); head=eraseLastRec(head,d); break;
      		case 'i':	
			scanf("%d",&d); head=insert(head,d); break;
		case 'j':
			scanf("%d",&d); insertEnd(&head,d); break;
		case 'J':
			scanf("%d",&d); head=insertEndRec(head,d); break;
		case 'l':
			printf("length = %d\n",length(head)); break;
		case 'L':
			printf("length = %d\n",lengthRec(head)); break;
		case 'p':	
			print(head); break;
      		case 's':	
			scanf("%d",&d);
			printf(find(head,d)? "Found\n": "Not found\n"); 
			break;
		default: continue;
          	}
		printf("Command: ");
	}
   	eraseAll(head); head=NULL;
	printf("List erased\n");
}
